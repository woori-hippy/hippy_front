import React from "react";
import MarketContainer from "../container/MarketContainer";

const MarketPage = (props) => {
  return <MarketContainer />;
};

export default MarketPage;
