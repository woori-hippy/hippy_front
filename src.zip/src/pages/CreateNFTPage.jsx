import React from "react";
import CreateNFTContainer from "../container/CreateNFTContainer";

const CreateNFTPage = (props) => {
  return <CreateNFTContainer />;
};

export default CreateNFTPage;
