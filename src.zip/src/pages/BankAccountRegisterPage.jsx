import React from "react";
import BankAccountRegisterContainer from "../container/BankAccountRegisterContainer";

const BankAccountRegisterPage = (props) => {
  return <BankAccountRegisterContainer />;
};

export default BankAccountRegisterPage;
