import React from "react";
import CreateProductContainer from "../container/CreateProductContainer";

const CreateProductPage = (props) => {
  return <CreateProductContainer />;
};

export default CreateProductPage;
