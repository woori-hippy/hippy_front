import React from "react";
import MypageContainer from "../container/MypageContainer";

const MypagePage = (props) => {
  return <MypageContainer />;
};

export default MypagePage;
