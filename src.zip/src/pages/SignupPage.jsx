import React from "react";
import SignupContainer from "../container/SignupContainer";

const SignupPage = (props) => {
  return <SignupContainer />;
};

export default SignupPage;
