import React from "react";
import MainContainer from "../container/MainContainer";

const MainPage = (props) => {
  return <MainContainer />;
};

export default MainPage;
