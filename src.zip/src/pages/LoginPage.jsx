import React from "react";
import LoginContainer from "../container/LoginContainer";

const LoginPage = (props) => {
  return <LoginContainer />;
};

export default LoginPage;
