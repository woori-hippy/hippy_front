import axios from "axios";
import IpfsApi from "ipfs-api";

export const getHash = async (buffer, callback) => {
  const ipfsApi = IpfsApi({
    host: "ipfs.infura.io",
    port: 5001,
    protocol: "https",
  });
  callback(true);
  const response = await ipfsApi.files.add(buffer);
  return response[0].hash;
};
